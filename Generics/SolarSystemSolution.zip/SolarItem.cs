﻿namespace SolarSystemSolution;

public class SolarItem
{
	public string Description { get; set; }
	
	public SolarItemType Type { get; set; }
	
	public SolarItem(string Description, SolarItemType Type)
	{
		this.Description = Description;
		this.Type = Type;
	}
}

public enum SolarItemType { Star, Planet, Trabant }